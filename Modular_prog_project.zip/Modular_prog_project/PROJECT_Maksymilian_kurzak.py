def get_info():
    name = str(input("Name: "))
    while name == "":
        name = str(input("Try again >>"))
    name = name.lower()

    password = str(input("Password: "))
    while password == "":
        password = str(input("Try again >>"))

    names_list = []
    passwd_list = []

    with open("login_data.txt", "r") as my_login:
        for line in my_login:
            line = line.rstrip()
            line_data = line.split(":")
            text_name = line_data[0]
            text_passwd = line_data[1]
            names_list.append(text_name)
            passwd_list.append(text_passwd)


    if name in names_list:
        if password in passwd_list:
            print(f"Welcome {name}")
            print("-" * 55)
        else:
            print("Login failed\nExiting Module Record System")
            quit()
    else:
        print("Login failed\nExiting Module Record System")
        quit()


def options():
    print("Module Record System - Options")
    print("-" * 35)
    print("1. Record Attendance\n"
          "2. Generate Statistics\n"
          "3. Exit")
    option = int(input(">>"))
    while 1 > option or option > 3:
        option = str(input("Try again >>"))

    if option == 1:
        rec_attendance()
    elif option == 2:
        gen_stats()
    elif option == 3:
        print("Exiting Module Record System")
        quit()
    else:
        print("Error")
        quit()

def rec_attendance():
    print("Module Record System - Attendance - Choose a module")
    print("-" * 55)

    with open("modules.txt", "r") as my_file:
        for module in my_file:
            module_data = module.split(",")
            print(module_data[0])
    my_file.close()

    module_choice = int(input(">>"))
    while module_choice < 1 or module_choice > 2:
        module_choice = int(input("Try Again >>"))

    if module_choice == 1:
        print("Module Record System - Attendance - SOFT_6017")
        print("-" * 55)

        with open("SOFT_6017.txt", "r") as soft_6017:
            print(f"There are 3 students enrolled")
            loop_num = 0
            new_val = ""
            for person in soft_6017:
                loop_num += 1
                person_data = person.split(",")
                name = person_data[0]
                present = int(person_data[1])
                absent = int(person_data[2])
                print(f"Student #{loop_num}: {name}")
                print("1. Present\n"
                      "2. Absent")
                status = int(input(">>"))

                if status == 1:
                    present += 1
                elif status == 2:
                    absent += 1

                new_val += f"{name},{present},{absent}\n"

        with open("SOFT_6017.txt", "w") as connection:
            connection.write(new_val)

        soft_6017.close()

        print("SOFT_6017 as been updated.")

    elif module_choice == 2:
        print("Module Record System - Attendance - SOFT_6018")
        print("-" * 55)

        with open("SOFT_6018.txt", "r") as soft_6018:
            print("There are 2 students enrolled")
            loop_num = 0
            new_val2 = ""
            for person in soft_6018:
                loop_num += 1
                person_data = person.split(",")
                name = person_data[0]
                present = int(person_data[1])
                absent = int(person_data[2])
                print(f"Student #{loop_num}: {name}")
                print("1. Present\n"
                      "2. Absent")
                status = int(input(">>"))

                while status < 1 or status > 2:
                    status = int(input("Try again\n>>"))

                if status == 1:
                    present += 1
                elif status == 2:
                    absent += 1

                new_val2 += f"{name},{present},{absent}\n"

        with open("SOFT_6018.txt", "w") as connection:
            connection.write(new_val2)

        soft_6018.close()

        print("SOFT_6018 as been updated.")


def gen_stats():
    att_under40 = ""
    att_under40_count = 0
    total_att = 0
    total_pres = 0
    print("Module Record Systems - Average Attendance Data")
    print("-" * 55)
    with open("SOFT_6017.txt", "r") as soft_6017:
        print(f"Modular Programming - SOFT_6017")
        for person in soft_6017:
            person_data = person.split(",")
            total_att += int(person_data[1]) + int(person_data[2])
            total_pres += int(person_data[1])
        attendance_percent = (total_pres / total_att) * 100
        print(f"{attendance_percent:.1f}%")
        print("*" * round(attendance_percent/10))

        if attendance_percent < 40:
            att_under40 += "\nmodular programming"
            att_under40_count += 1

    soft_6017.close()

    total_att2 = 0
    total_pres2 = 0
    with open("SOFT_6018.txt", "r") as soft_6018:
        print(f"Programming Fundamentals - SOFT_6018")
        for person in soft_6018:
            person_data = person.split(",")
            total_att2 += int(person_data[1]) + int(person_data[2])
            total_pres2 += int(person_data[1])
        attendance_percent2 = (total_pres2 / total_att2) * 100
        print(f"{attendance_percent2:.1f}%")
        print("*" * round(attendance_percent2/10))

        if attendance_percent2 < 40:
            att_under40 += "\nprogramming fundamentals"
            att_under40_count += 1

    soft_6018.close()

    if attendance_percent > attendance_percent2:
        print(f"The best attended module is Modular Programming with a {attendance_percent:.1f}% attendance rate.")

    elif attendance_percent2 > attendance_percent:
        print(f"The best attended module is Programming Fundamentals with a {attendance_percent2:.1f}% attendance rate.")

    print(f"There is {att_under40_count} module(s) with attendance rate under 40%:")
    print(att_under40)

    from datetime import datetime

    today_date = datetime.now().date()
    filename = f"Attendance-Stats-{today_date}.txt"

    with open(filename, "w") as data:
        data.write(f"SOFT_6017 - {attendance_percent:.1f}%\n"
                   f"SOFT_6018 - {attendance_percent2:.1f}%")

    data.close()
    print("-" * 55)
    print(f"All above info has been stored in {filename}")


def main():
    print("Module Record System - Login")
    print("-" * 35)
    get_info()
    options()

main()